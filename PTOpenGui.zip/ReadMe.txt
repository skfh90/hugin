Panorama tools open GUI

This program is designed for panorama image stitching. 
Home page is http://www.nic.fi/~juhe/ptbcbgui/


Installing

	Install Panorama tools at first. This program uses it. Second step is to
	copy file(s) for this program.

	Easy way:
	Extract PTOpenGUI.zip to new directory with extracted DLL files 
	and run program from there. (This means Dll.zip where vcl*.* files are.) 
	No extra setup program is needed. Program works without ImageMagick but TIFF
	support is limited and PNG+... files are not read. JPG and BMP -files are 
	fastest to use and works always.

	Uninstall:
	Delete files that are copied in previous case. If you want to clean 
	everything then use regedit and clear values under
	HKEY_CURRENT_USER\Software\JuHe\PTOpenGui. Default settings are found from 
	there.

	"Full install":
	PTOpenGui can be run in system where BorlandC++Builder 4 and ImageMagick is
	already installed.
	So if your system has working version of ImageMagick then you do not need to 
	change ImageMagick. I suppose that nearly all versions of ImageMagick are 
	OK but I were used version 5.5.4-Q16. ImageMagick can be found 
	from http://www.imagemagick.org/. 

	Current style demands that if ImageMagick is used then Windows registry must
	have correct value (setup program sets it correctly). Is this OK?


Compiling

	Extract source code to suitable working directory. 
	ImageMagick h-files can be used from those files that came in this packet or 
	you can use lastest that can be downloaded from ImageMagick www-files. 
	Only h-files are needed for compiling.

	Some parts of code is same as PanoTools src has or slightly modified.

Version changes
	Look at http://www.nic.fi/~juhe/ptbcbgui/
